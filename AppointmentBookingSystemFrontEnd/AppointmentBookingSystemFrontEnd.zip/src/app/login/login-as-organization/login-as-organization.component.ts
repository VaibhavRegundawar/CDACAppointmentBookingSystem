import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Organization } from 'src/app/models/organization.model';
import { LoginService } from '../login.service';

@Component({
  selector: 'app-login-as-organization',
  templateUrl: './login-as-organization.component.html',
  styleUrls: ['./login-as-organization.component.css']
})
export class LoginAsOrganizationComponent implements OnInit {

  constructor(private router:Router,private loginservice:LoginService ) { }

  ngOnInit(): void {
  }
  organization:Organization=new Organization;
  msg!:string;

  onSubmit()
  {
   
    this.loginservice.LoginAsOrganization(this.organization).subscribe(response=>{
     
      console.log(response);
      localStorage.setItem("organizationid",response.orgId);
      this.router.navigate(['/organization/organization-dashboard']);
      
    },error=>{
      this.msg="Invalid Credential Details,Please Register First!!!!!";
    })
  }
}
