import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LoginAsCustomerComponent } from './login-as-customer.component';

describe('LoginAsCustomerComponent', () => {
  let component: LoginAsCustomerComponent;
  let fixture: ComponentFixture<LoginAsCustomerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LoginAsCustomerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginAsCustomerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
