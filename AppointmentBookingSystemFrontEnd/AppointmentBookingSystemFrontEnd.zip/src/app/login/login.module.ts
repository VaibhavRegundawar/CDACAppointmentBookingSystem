import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoginOptionsComponent } from './login-options/login-options.component';
import { LoginAsAdminComponent } from './login-as-admin/login-as-admin.component';
import { LoginAsEmployeeComponent } from './login-as-employee/login-as-employee.component';
import { LoginAsCustomerComponent } from './login-as-customer/login-as-customer.component';
import { LoginAsOrganizationComponent } from './login-as-organization/login-as-organization.component';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { LoginService } from './login.service';
import { HttpClientModule } from '@angular/common/http';




@NgModule({
  declarations: [LoginOptionsComponent, LoginAsAdminComponent, LoginAsEmployeeComponent, LoginAsCustomerComponent, LoginAsOrganizationComponent],
  imports: [
    CommonModule,RouterModule,FormsModule,HttpClientModule
  ],
  exports:[
    LoginOptionsComponent, LoginAsAdminComponent, LoginAsEmployeeComponent, LoginAsCustomerComponent, LoginAsOrganizationComponent
  ],
  providers: [
    LoginService
  ]
})
export class LoginModule { }
