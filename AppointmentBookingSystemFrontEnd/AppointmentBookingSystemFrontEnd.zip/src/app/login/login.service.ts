import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Customer } from '../models/customer.model';
import { Observable } from 'rxjs';
import { Organization } from '../models/organization.model';
import { Employee } from '../models/employee.model';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(private Http:HttpClient) { }

  url = 'http://localhost:8080';

  public LoginAsOrganization(organization:Organization):Observable<any>
   {
     return this.Http.post(this.url+"/organizations/login",organization);
   }
   
   public LoginAsCustomer(customer:Customer):Observable<any>
   {
     return this.Http.post(this.url+"/customers/login",customer);
   }
   public LoginAsEmployee(employee:Employee):Observable<any>
   {
     return this.Http.post(this.url+"/employees/login",employee);
   }


   
}
