import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Employee } from 'src/app/models/employee.model';
import { LoginService } from '../login.service';

@Component({
  selector: 'app-login-as-employee',
  templateUrl: './login-as-employee.component.html',
  styleUrls: ['./login-as-employee.component.css']
})
export class LoginAsEmployeeComponent implements OnInit {

  constructor(private router:Router,private loginservice:LoginService) { }
  employee:Employee=new Employee;
  msg!:string;
  ngOnInit(): void {
  }

  onSubmit()
  {
   
    this.loginservice.LoginAsEmployee(this.employee).subscribe(response=>{
     
      console.log(response);
      localStorage.setItem("employeeid",response.empId);
      this.router.navigate(['/employee/employee-dashboard']);
      
    },error=>{
      this.msg="Invalid Credential Details,Please Register First!!!!!";
    })
    console.log(this.employee.email);
    console.log(this.employee.password);
  }
 
}
