export class TypeOfOrganization
{
    orgTypeId!:number;
    orgType!:string;
    constructor(){
    }
    
}