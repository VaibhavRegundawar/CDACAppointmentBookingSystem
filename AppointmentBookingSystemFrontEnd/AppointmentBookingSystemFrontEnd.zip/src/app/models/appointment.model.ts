

export class Appointment {
    aptId!: number;
    date!: any;
    startingTime!: number;
    endingTime!: number;
    totalPrice!: number;

    appointmentOfOrgType!: {

        orgTypeId: number;
        orgType: string;
    }
    appointmentOfOrg!: {
        orgId: number;
        email: string;
        password: string;
        nameOfOrganization: string;
        mobileNo: string;
        city: string;
        org_img: any;
        imageContentType: string;
        durationPerService: number;
    }
    appointmentOfEmp!: {
        empId: number;
        email: string;
        password: string;
        firstName: string;
        lastName: string;
        gender: string;
        mobileNo: string;
    }
    appointmentOfCust!: {
        cstId: number;
        email: string;
        password: string;
        firstName: string;
        lastName: string;
        gender: string;
        mobileNo: string;
    }
    constructor() {

    }

}