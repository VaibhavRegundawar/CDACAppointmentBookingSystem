
export class Customer {
    cstId!: number;
    email!: string;
    password!: string;
    firstName!: string;
    lastName!: string;
    gender!: string;
    mobileNo!: string;
    bookForOrganization!: {
        orgId: number;
        email: string;
        password: string;
        nameOfOrganization: string;
        mobileNo: string;
        city: string;
        org_img: any;
        imageContentType: string;
        durationPerService: number;
    }

}

