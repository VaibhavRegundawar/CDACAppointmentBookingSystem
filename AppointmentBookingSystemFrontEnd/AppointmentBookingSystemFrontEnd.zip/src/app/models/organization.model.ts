
export class Organization
{
    orgId!:number;
    email!:string;
    password!:string;
    nameOfOrganization!:string;
    mobileNo!:string;
    city!:string;
    org_img!:any;
    imageContentType!:string;
    durationPerService!:number;
    belongsToOrgType!:{
        
        orgTypeId:number;
        orgType:string;
    }
    constructor(){
        
    }
    
}