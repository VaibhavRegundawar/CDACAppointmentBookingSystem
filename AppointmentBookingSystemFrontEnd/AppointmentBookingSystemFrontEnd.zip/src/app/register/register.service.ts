import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Customer } from '../models/customer.model';
import { Organization } from '../models/organization.model';
import { TypeOfOrganization } from '../models/typeOfOrganization.model';


@Injectable({
  providedIn: 'root'
})
export class RegisterService {

  constructor(private Http:HttpClient) { }

  url = 'http://localhost:8080';

  getTypeOfOrgList(): Observable<TypeOfOrganization[]>{
    return this.Http.get<TypeOfOrganization[]>(this.url+"/typeOfOrgs");
  }


  getTypeOfOrganizationById(id:number)
  {
    return this.Http.get<TypeOfOrganization>(this.url +"/typeOfOrgs" + `/${id}`);
  }



  public RegisterCustomer(customer:Customer):Observable<any>
  {
    return this.Http.post(this.url+"/customers/register",customer);
  }
  public RegisterOrganization(selectedFile: File,organization:Organization,orgTypeselected:TypeOfOrganization):Observable<any>
  {
    const uploadData = new FormData();
    uploadData.append("imageFile", selectedFile);
   uploadData.append("dtls",JSON.stringify(organization));
   uploadData.append("TypeOfOrg", JSON.stringify(orgTypeselected));
   return this.Http.post(this.url+"/organizations/register", uploadData, { responseType: 'text' });
 
  }


}
