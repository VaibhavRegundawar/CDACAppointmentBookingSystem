import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Customer } from 'src/app/models/customer.model';


import { RegisterService } from '../register.service';

@Component({
  selector: 'app-register-as-customer',
  templateUrl: './register-as-customer.component.html',
  styleUrls: ['./register-as-customer.component.css']
})
export class RegisterAsCustomerComponent implements OnInit {

  customer:Customer=new Customer;
 
  conpassword=""
  msg=""
  
  constructor(private router:Router ,private registerservice:RegisterService) {}


   

  ngOnInit(): void {
  
  }

  onSubmit()
  {
    this.registerservice.RegisterCustomer(this.customer).subscribe(response=>{
      console.log(response);
      this.router.navigate(['/login/customer']);
    },error=>{
      this.msg="Customer Already Register with this EmailId";
    })
  }

}
