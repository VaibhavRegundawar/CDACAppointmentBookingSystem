import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RegisterAsCustomerComponent } from './register-as-customer/register-as-customer.component';
import { RegisterAsOrganizationComponent } from './register-as-organization/register-as-organization.component';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';



@NgModule({
  declarations: [RegisterAsCustomerComponent, RegisterAsOrganizationComponent],
  imports: [
    CommonModule,RouterModule,FormsModule,HttpClientModule
  ],
  exports:[RegisterAsCustomerComponent, RegisterAsOrganizationComponent]
})
export class RegisterModule { }
