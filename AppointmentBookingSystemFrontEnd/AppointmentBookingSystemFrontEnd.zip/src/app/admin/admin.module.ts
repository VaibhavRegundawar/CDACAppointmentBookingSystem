import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AdminService } from './admin.service';



@NgModule({
  declarations: [AdminDashboardComponent],
  imports: [
  CommonModule,RouterModule,FormsModule,HttpClientModule
  ],
  exports:[AdminDashboardComponent],
  providers:[AdminService]

})
export class AdminModule { }
