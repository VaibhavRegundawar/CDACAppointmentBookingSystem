import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminDashboardComponent } from './admin/admin-dashboard/admin-dashboard.component';
import { CustomerDashboardComponent } from './customer/customer-dashboard/customer-dashboard.component';
import { ListOfOrgsComponent } from './customer/list-of-orgs/list-of-orgs.component';
import { UpdateCustomerProfileComponent } from './customer/update-customer-profile/update-customer-profile.component';


import { ViewCustomerBookingsComponent } from './customer/view-customer-bookings/view-customer-bookings.component';
import { ViewCustomerProfileComponent } from './customer/view-customer-profile/view-customer-profile.component';

import { EmployeeDashboardComponent } from './employee/employee-dashboard/employee-dashboard.component';
import { UpdateEmployeeProfileComponent } from './employee/update-employee-profile/update-employee-profile.component';
import { ViewEmployeeBookingsComponent } from './employee/view-employee-bookings/view-employee-bookings.component';
import { LoginAsAdminComponent } from './login/login-as-admin/login-as-admin.component';
import { LoginAsCustomerComponent } from './login/login-as-customer/login-as-customer.component';
import { LoginAsEmployeeComponent } from './login/login-as-employee/login-as-employee.component';
import { LoginAsOrganizationComponent } from './login/login-as-organization/login-as-organization.component';
import { LoginOptionsComponent } from './login/login-options/login-options.component';
import { AddEmployeeComponent } from './organization/add-employee/add-employee.component';
import { AddServiceComponent } from './organization/add-service/add-service.component';
import { OrganizationDashboardComponent } from './organization/organization-dashboard/organization-dashboard.component';
import { UpdateOrganizationProfileComponent } from './organization/update-organization-profile/update-organization-profile.component';
import { ViewOrganizationBookingsComponent } from './organization/view-organization-bookings/view-organization-bookings.component';
import { ViewOrganizationEmployeesComponent } from './organization/view-organization-employees/view-organization-employees.component';

import { RegisterAsCustomerComponent } from './register/register-as-customer/register-as-customer.component';
import { RegisterAsOrganizationComponent } from './register/register-as-organization/register-as-organization.component';
import { AboutUsComponent } from './standard/about-us/about-us.component';
import { ContactUsComponent } from './standard/contact-us/contact-us.component';
import { HomeComponent } from './standard/home/home.component';
import { ServicesComponent } from './standard/services/services.component';
import { CustGuardGuard } from "./cust-guard.guard";
import { EmpGuardGuard } from './emp-guard.guard';
import { OrgGuardGuard } from './org-guard.guard';
const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'aboutus', component: AboutUsComponent },
  { path: 'contactus', component: ContactUsComponent },
  { path: 'services', component: ServicesComponent },
  {
    path: 'login', children: [
      { path: '', component: LoginOptionsComponent },
      { path: 'admin', component: LoginAsAdminComponent },
      { path: 'organization', component: LoginAsOrganizationComponent },
      { path: 'employee', component: LoginAsEmployeeComponent },
      { path: 'customer', component: LoginAsCustomerComponent }
    ]
  },
  { path: 'registerasorganization', component: RegisterAsOrganizationComponent },
  { path: 'registerascustomer', component: RegisterAsCustomerComponent },


  { path: 'admin/dashboard', component: AdminDashboardComponent },




  { path: 'organization/organization-dashboard', component: OrganizationDashboardComponent,canActivate :[OrgGuardGuard] },
  { path: 'organization/update-profile', component: UpdateOrganizationProfileComponent,canActivate :[OrgGuardGuard]  },
  { path: 'organization/view-employees', component:ViewOrganizationEmployeesComponent,canActivate :[OrgGuardGuard]  },
  { path: 'organization/add-employee', component: AddEmployeeComponent,canActivate :[OrgGuardGuard]  },
  { path: 'organization/add-service', component:AddServiceComponent,canActivate :[OrgGuardGuard] },
  { path: 'organization/view-appointment', component: ViewOrganizationBookingsComponent,canActivate :[OrgGuardGuard]  },


  { path: 'employee/employee-dashboard', component: EmployeeDashboardComponent ,canActivate :[EmpGuardGuard]},
  {path:'employee/view-appointment', component:ViewEmployeeBookingsComponent,canActivate :[EmpGuardGuard]},
  {path:'employee/update-profile',component:UpdateEmployeeProfileComponent,canActivate :[EmpGuardGuard]},




  { path: 'customer/customer-dashboard', component: CustomerDashboardComponent, canActivate :[CustGuardGuard] },
  { path: 'customer/listof-organizations', component: ListOfOrgsComponent, canActivate :[CustGuardGuard] },
  { path: 'customer/view-profile', component: ViewCustomerProfileComponent, canActivate :[CustGuardGuard] },
  { path: 'customer/update-profile', component: UpdateCustomerProfileComponent, canActivate :[CustGuardGuard] },
  { path: 'customer/view-appointment', component: ViewCustomerBookingsComponent, canActivate :[CustGuardGuard] }










];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
