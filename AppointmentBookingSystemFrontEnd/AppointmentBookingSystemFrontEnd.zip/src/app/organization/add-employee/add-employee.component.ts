import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Employee } from 'src/app/models/employee.model';
import { OrganizationService } from '../organization.service';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {

  employee: Employee = new Employee;
  selectedService: any;
  service: any;
  listofservices: any;
  orgid = parseInt(localStorage.getItem("organizationid")!);
  conpassword = ""


  constructor(private router: Router, private organizationservice: OrganizationService, private toastr: ToastrService) { }

  ngOnInit(): void {

    this.getlistOfServices();
  }

  logout(){
    localStorage.removeItem('organizationid');
    this.router.navigate(['/login/organization']);
  }
  getlistOfServices() {
    this.organizationservice.getServices().subscribe(
      servicesResponse => {
        const filters = {
          fororganization: (fororganization: { orgId: any; }) => fororganization.orgId == this.orgid
        };
        var filtered = this.filterArray(servicesResponse, filters);
        this.listofservices = filtered;
        console.log(this.listofservices);
      },
      error => {
        console.log(error);
      }
    );
  }

  
  onOptionsSelected() {
    this.organizationservice.getServiceById(this.selectedService).subscribe(resp => 
      {
         this.service = resp;    
      },
      error =>{
        
      })
  }


  onSubmit() {
    var addobject = {

      "email": this.employee.email,
      "password": this.employee.password,
      "firstName": this.employee.firstName,
      "lastName": this.employee.lastName,
      "gender": this.employee.gender,
      "mobileNo": this.employee.mobileNo,

      "workForOrganization": {
        "orgId": this.orgid,
      },
      "serviceProvided": {
        "serId": this.service.serId,
      }
    };
    console.log(addobject);
    this.organizationservice.addEmployee(addobject).subscribe(response => {
      console.log(response);
      this.toastr.success('Successfull!', 'Employee Added Successfully!');
    }, error => {
      this.toastr.warning('Error!', 'Employee Already exist!');
      ;
    })
  }

  filterArray(array: any[], filters: { [x: string]: (arg0: any) => unknown; }) {
    const filterKeys = Object.keys(filters);
    return array.filter((item: { [x: string]: any; }) => {
      // validates all filter criteria
      return filterKeys.every(key => {
        // ignores non-function predicates
        if (typeof filters[key] !== 'function') return true;
        return filters[key](item[key]);
      });
    });
  }

}
