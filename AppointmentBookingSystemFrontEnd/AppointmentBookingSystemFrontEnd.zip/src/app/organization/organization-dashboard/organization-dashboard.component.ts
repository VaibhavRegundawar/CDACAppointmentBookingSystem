import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Organization } from 'src/app/models/organization.model';
import { OrganizationService } from '../organization.service';

@Component({
  selector: 'app-organization-dashboard',
  templateUrl: './organization-dashboard.component.html',
  styleUrls: ['./organization-dashboard.component.css']
})
export class OrganizationDashboardComponent implements OnInit {

  organization:Organization=new Organization;
  orgid = parseInt(localStorage.getItem("organizationid")!);
  
  constructor(private router:Router,private organizationservice:OrganizationService) { }
  ngOnInit(): void {
    this.getorganization();
    
  }
  getorganization()
  {
    this.organizationservice.getOrganizationById(this.orgid).subscribe(data => {
      console.log(data);
      this.organization=data;  
      })
  }
  logout(){
    localStorage.removeItem('organizationid');
    this.router.navigate(['/login/organization']);
  }
  onSubmit()
  {

  }


}
