import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Service } from 'src/app/models/service.model';
import { OrganizationService } from '../organization.service';

@Component({
  selector: 'app-add-service',
  templateUrl: './add-service.component.html',
  styleUrls: ['./add-service.component.css']
})
export class AddServiceComponent implements OnInit {

  constructor(private router: Router, private organizationservice: OrganizationService, private toastr: ToastrService) { }

  orgid = parseInt(localStorage.getItem("organizationid")!);
  service: Service = new Service;
  ngOnInit(): void {
  }

  logout(){
    localStorage.removeItem('organizationid');
    this.router.navigate(['/login/organization']);
  }

  onSubmit() {
    var addobject = {

      "serviceName": this.service.serviceName,
      "price": this.service.price,

      "fororganization": {
        "orgId": this.orgid,
      }

    };
    console.log(addobject);
    this.organizationservice.addService(addobject).subscribe(response => {
      console.log(response);
      this.toastr.success('Successfull!', 'Service Added Successfully!');
    }, error => {
      this.toastr.warning('Error!', 'Something Went Wrong!');
      ;
    })
  }

}
