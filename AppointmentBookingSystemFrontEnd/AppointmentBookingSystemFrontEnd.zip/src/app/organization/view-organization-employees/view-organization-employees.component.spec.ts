import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewOrganizationEmployeesComponent } from './view-organization-employees.component';

describe('ViewOrganizationEmployeesComponent', () => {
  let component: ViewOrganizationEmployeesComponent;
  let fixture: ComponentFixture<ViewOrganizationEmployeesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewOrganizationEmployeesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewOrganizationEmployeesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
