import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Organization } from 'src/app/models/organization.model';
import { TypeOfOrganization } from 'src/app/models/typeOfOrganization.model';
import { OrganizationService } from '../organization.service';

@Component({
  selector: 'app-update-organization-profile',
  templateUrl: './update-organization-profile.component.html',
  styleUrls: ['./update-organization-profile.component.css']
})
export class UpdateOrganizationProfileComponent implements OnInit {

  constructor(private router:Router,private organizationservice:OrganizationService,private toastr: ToastrService) { }
  
  organization:Organization=new Organization;
  orgType:TypeOfOrganization=new TypeOfOrganization;
  public TypeOfOrgs!:TypeOfOrganization[];
  conpassword="";
  msg="";
  selectedFile:any = null;
  selectedtype!:number;
  orgid = parseInt(localStorage.getItem("organizationid")!);
  ngOnInit(): void {

    this.organizationservice.getOrganizationById(this.orgid).subscribe(data => {
      console.log(data);
      this.organization=data;  
      })
    
  }
  logout(){
    localStorage.removeItem('organizationid');
    this.router.navigate(['/login/organization']);
  }

  onOptionsSelected() {
    this.organizationservice.getTypeOfOrganizationById(this.selectedtype).subscribe(resp => 
      {
         this.orgType = resp;    
      },
      error =>{
        this.msg=error.message
      })
  }
  public onFileChanged(event:any) {
    console.log(event);
    this.selectedFile = event.target.files[0];
  }
  onSubmit()
  {
   
    this.organizationservice.UpdateOrganization(this.organization).subscribe(
      resp => {
        console.log(resp);
        this.toastr.success('Successfull!', 'Updated Successfully!');
       
      },error=>{
        
      }
    );
  }
}
