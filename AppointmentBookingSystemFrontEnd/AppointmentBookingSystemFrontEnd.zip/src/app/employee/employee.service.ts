import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Employee } from '../models/employee.model';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  url ='http://localhost:8080/'

  constructor(private httpClient: HttpClient) { }

  getEmployee(id:any){
    return this.httpClient.get<any>(this.url+"/employees"+`/${id}`);
  }

  getAppointment(){
    return this.httpClient.get(this.url+"appointments");
  }
  public UpdateEmployee(employee:Employee)
  {
    return this.httpClient.post(this.url+"/employees/update",employee);
  }
}
