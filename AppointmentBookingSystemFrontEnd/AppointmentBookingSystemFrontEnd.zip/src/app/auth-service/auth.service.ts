import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor() { }
  public isLoggedInCustomer() {
    return localStorage.getItem('customerid') !== null;
  }
  public isLoggedInOrganization() {
    return localStorage.getItem('organizationid') !== null;
  }
  public isLoggedInEmployee() {
    return localStorage.getItem('employeeid') !== null;
  }

}

