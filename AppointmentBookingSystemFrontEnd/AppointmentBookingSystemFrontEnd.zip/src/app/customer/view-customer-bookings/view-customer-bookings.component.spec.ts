import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewCustomerBookingsComponent } from './view-customer-bookings.component';

describe('ViewCustomerBookingsComponent', () => {
  let component: ViewCustomerBookingsComponent;
  let fixture: ComponentFixture<ViewCustomerBookingsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewCustomerBookingsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewCustomerBookingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
