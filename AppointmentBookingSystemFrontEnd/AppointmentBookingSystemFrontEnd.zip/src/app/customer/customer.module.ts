import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CustomerDashboardComponent } from './customer-dashboard/customer-dashboard.component';
import { CustomerService } from './customer.service';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';



import { ListOfOrgsComponent } from './list-of-orgs/list-of-orgs.component';

import { ViewCustomerProfileComponent } from './view-customer-profile/view-customer-profile.component';
import { UpdateCustomerProfileComponent } from './update-customer-profile/update-customer-profile.component';
import { ViewCustomerBookingsComponent } from './view-customer-bookings/view-customer-bookings.component';

@NgModule({
  declarations: [CustomerDashboardComponent,  ListOfOrgsComponent,ViewCustomerProfileComponent, UpdateCustomerProfileComponent, ViewCustomerBookingsComponent],
  imports: [
    CommonModule,
    RouterModule,
    FormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    BsDatepickerModule.forRoot(),
  ],
  exports:[CustomerDashboardComponent],
  providers:[CustomerService]
})
export class CustomerModule { }
