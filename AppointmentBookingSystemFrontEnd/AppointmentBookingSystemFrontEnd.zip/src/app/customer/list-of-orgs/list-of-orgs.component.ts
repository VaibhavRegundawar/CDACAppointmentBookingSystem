import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Organization } from 'src/app/models/organization.model';
import { Service } from 'src/app/models/service.model';
import { Slot } from 'src/app/models/slot.model';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-list-of-orgs',
  templateUrl: './list-of-orgs.component.html',
  styleUrls: ['./list-of-orgs.component.css']
})
export class ListOfOrgsComponent implements OnInit {

  public orgs!: Organization[];
  public oid: any;
  public employee: any;
  public Allservices: any;
  public Allslots: any;
  service: Service = new Service;
  slot: Slot = new Slot;
  public selectedDate: any;
  public selectedEmployeeId: any;
  public selectedSlotId: any;
  public selectedServiceId: any;

  orgtype!: number;


  bsValue = new Date();



  constructor(private router: Router, private customerService: CustomerService, private toastr: ToastrService) { }

  ngOnInit(): void {
    this.orgtype = parseInt(localStorage.getItem("orgTypeSelected")!);
    console.log(this.orgtype);
    this.getOrganisations();
  }

  logout(){
    localStorage.removeItem('customerid');
    localStorage.removeItem('orgTypeSelected');
    this.router.navigate(['/login/customer']);
  }

  onEmployeeChangeHandle(data: any) {
    console.log("emp change from drop down" + data.target.value);

  }

  onServiceChangeHandle(data: any) {
    this.getEmployees();
    console.log("Service change from drop down" + data.target.value);
    this.customerService.getSelectedService(this.selectedServiceId).subscribe(
      response => {
        console.log(response);
        this.service = response;
      },
      error => {
        console.log(error);

      }
    );


  }

  onChangeHandleForSLot(data: any) {

    console.log("slot change from drop down" + data.target.value);
    this.customerService.getSelectedSlot(this.selectedSlotId).subscribe(
      response => {
        console.log(response);
        this.slot = response;

      },
      error => {
        console.log(error);

      }
    );


  }

  handleDateChange(e: any) {
    console.log("emp id from date change" + this.selectedEmployeeId)
    console.log(e.target.value);
    this.selectedDate = e.target.value;
    if (this.selectedDate == null) {
      this.selectedDate = new Date();
      console.log("todays date" + this.selectedDate);
    }
    this.customerService.getSlotsByDate(this.selectedDate)
      .subscribe(
        (response: any) => {
          const filters = {
            employee: (employee: { empId: any; }) => employee.empId == this.selectedEmployeeId
          };
          var filtered = this.filterArray(response, filters);
          this.Allslots = filtered;
        },
        error => {
          console.log("exception occured while getting slots")
        }
      );
  }

  book(bookingForm: NgForm) {
    console.log(bookingForm.value);
    var updateSlotObj = {
      "slotstatus": "NOT_AVAILABLE",

    };
    this.selectedSlotId = parseInt(bookingForm.controls['selectedSlotId'].value);
    console.log(updateSlotObj);
    this.customerService.updateSlots(updateSlotObj, this.selectedSlotId).subscribe(
      response => {
        console.log(response);
      },
      error => {
        console.log(error);
      }
    );

    var bookingObject = {
     
      "date": this.selectedDate,
      "totalPrice": this.service.price,
      "startingTime": this.slot.startingTime,
      "endingTime": this.slot.endingTime,

      "appointmentOfOrg": {
        "orgId": this.oid,
      },
      "appointmentOfEmp": {
        "empId": parseInt(bookingForm.controls['selectedEmployeeId'].value),
      },
      "appointmentOfCust": {
        "cstId": parseInt(localStorage.getItem("customerid")!),
      },
      "appointmentOfOrgType": {
        "orgTypeId": this.orgtype,
      }
    };
    debugger;
    console.log(bookingObject);
    this.customerService.bookAppointment(bookingObject).subscribe(
      response => {
        console.log(response);
        this.toastr.success('Successfull!', 'Booked successfull!');
      },
      error => {
        console.log(error);
        this.toastr.warning('Error!', 'Problem in Appointment Booking !');
      }
    );
  }

  filterArray(array: any[], filters: { [x: string]: (arg0: any) => unknown; }) {
    const filterKeys = Object.keys(filters);
    return array.filter((item: { [x: string]: any; }) => {
      // validates all filter criteria
      return filterKeys.every(key => {
        // ignores non-function predicates
        if (typeof filters[key] !== 'function') return true;
        return filters[key](item[key]);
      });
    });
  }

  getEmployees() {
  
    this.customerService.getAllEmployees().subscribe(
      employeeResponse => {
        const filters = {
          serviceProvided: (serviceProvided: { serId: any; }) => serviceProvided.serId == this.selectedServiceId
        };
        var filtered = this.filterArray(employeeResponse, filters);
        this.employee = filtered;
      },
      error => {
        console.log(error);
      }
    );
  }

  getServices(data: any) {
    
    this.oid=data;
    this.customerService.getAllServices().subscribe(
      serviceResponse => {
        const filters = {
          fororganization: (fororganization: { orgId: any; }) => fororganization.orgId == this.oid
        };
        var filtered = this.filterArray(serviceResponse, filters);
        this.Allservices = filtered;
      },
      error => {
        console.log(error);
      }
    );
  }

  getOrganisations() {
    this.customerService.getOrganisations().subscribe(
      response => {
        const filters = {
          belongsToOrgType: (belongsToOrgType: { orgTypeId: any; }) => belongsToOrgType.orgTypeId == this.orgtype
        };
        var filtered = this.filterArray(response, filters);
        this.orgs = filtered;
        console.log(this.orgs)
        for (let i = 0; i < this.orgs.length; i++) {
          this.orgs[i].imageContentType = `data:${this.orgs[i].imageContentType};base64,${this.orgs[i].org_img}`;
        }
      },
      error => {
        console.log(error);
      }
    );
  }

}
