import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { CustomerService } from '../customer.service';
import { TypeOfOrganization } from 'src/app/models/typeOfOrganization.model';

@Component({
  selector: 'app-customer-dashboard',
  templateUrl: './customer-dashboard.component.html',
  styleUrls: ['./customer-dashboard.component.css']
})
export class CustomerDashboardComponent implements OnInit {
  constructor(private router: Router, private customerService: CustomerService) { }
  public TypeOfOrgs!:TypeOfOrganization[];
  orgTypeSelected:any;

  ngOnInit(): void {
    this.getTypeOfOrgs();
    
  }
  logout(){
    localStorage.removeItem('customerid');
    localStorage.removeItem('orgTypeSelected');
    this.router.navigate(['/login/customer']);
  }
  private getTypeOfOrgs(){
   
    this.customerService.getTypeOfOrgList().subscribe(response => {
      console.log(response);
      this.TypeOfOrgs=response;
    })
  }

  getTypeOfOrg(data: any)
  {
    this.orgTypeSelected=data;
    console.log(this.orgTypeSelected);
    localStorage.setItem("orgTypeSelected",this.orgTypeSelected);
      this.router.navigate(['/customer/listof-organizations']);
  }
}
