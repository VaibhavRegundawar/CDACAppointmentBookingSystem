import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { StandardModule } from './standard/standard.module';
import { LoginModule } from './login/login.module';
import { RegisterModule } from './register/register.module';
import { FormsModule } from '@angular/forms';
import { AdminModule } from './admin/admin.module';
import { EmployeeModule } from './employee/employee.module';
import { OrganizationModule } from './organization/organization.module';
import { CustomerModule } from './customer/customer.module';
import { ToastrModule } from 'ngx-toastr';
import { CarouselModule } from 'ngx-owl-carousel-o';





@NgModule({
  declarations: [
    AppComponent,
     
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    CarouselModule,
    BrowserAnimationsModule,
    StandardModule,
    LoginModule,
    RegisterModule,
    AdminModule,
    EmployeeModule,
    OrganizationModule,
    CustomerModule,
    ToastrModule.forRoot()
    
  ],
  providers: [
   
],
  bootstrap: [AppComponent]
})
export class AppModule { }
