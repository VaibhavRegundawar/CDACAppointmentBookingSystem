import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Organization } from 'src/app/models/organization.model';
import { TypeOfOrganization } from 'src/app/models/typeOfOrganization.model';
import { StandardService } from '../standard.service';

@Component({
  selector: 'app-services',
  templateUrl: './services.component.html',
  styleUrls: ['./services.component.css']
})
export class ServicesComponent implements OnInit {
  public TypeOfOrgs!:TypeOfOrganization[];
  constructor(private router:Router,private standardService:StandardService,private toastr: ToastrService) { }

  

  ngOnInit(): void {
    this.getTypeOfOrgs();
    
  }

  private getTypeOfOrgs(){
    this.standardService.getTypeOfOrgList().subscribe(response => {
      console.log(response);
      this.TypeOfOrgs=response;
    })
  }
    getTypeOfOrg(data: any){
        this.toastr.warning('Error!', 'You Have To Login First !!');
    }
  

  
}
